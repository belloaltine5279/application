
# API Spring

## Configuration 

- Version de Java 21
- Version de maven compatible avec Java 21 (par exemple Maven 3.9.9)
- BDD Postgres et/ou Timescale

Informations complémentaires :

- La configuration de la BDD (port, authentification) se fait dans le fichier : src\main\resources\application.properties
- Les tables dans la BD correspondent aux entités dans les fichiers : src\main\java\com\API_Meteo\entites
- La configuration des "chemins/routes" pour créer des requêtes est dans les fichiers : src\main\java\com\API_Meteo\controller
- Pour tester avec la BD vous pouvez tester avec l'application Postgres (sur Windows/Linux et config la BD avec pgAdmin4) en attendant la vrai BD

## Compilation / Execution 
Sur un terminal, à la source du dossier (là où il y a le fichier "pom.xml") exécuter : 

```bash
mvn clean install

mvn compile 

mvn spring-boot:run
```
L'API s'ouvrira sur le port 8080 (http://localhost:8080/) 

## Utilisation de l'API

L'API sert de liaison (intermédiaire) entre l'ETL, la base de données et le front (Angular). 
C'est un outil qui nous permettra donc de "centraliser" les différentes requêtes.

-> Pour manipuler l'API, nous utiliserons des requêtes HTTP (GET, POST, PUT, DELETE) 

## Voici les URLs pour les différents endpoints

- Pour accéder aux données climatiques (sur les jeux de données):
> http://localhost:8080/api/donnees-climatiques


- Pour accéder aux localisations (sur les jeux de données):
> http://localhost:8080/api/localisations


- Pour accéder à une station, ou à des données précises il faut rajouter son id après l'url, par exemple :
> http://localhost:8080/api/donnees-climatiques/1



## Récapitulatif des requêtes disponibles pour l'instant :

### Pour la table des données climatiques ("DonneesClimatiques")
    Récupérer toutes les données climatiques
        Méthode HTTP : GET
        Endpoint : /api/donnees-climatiques
        Description : Renvoie la liste complète de toutes les données climatiques.

    Ajouter une nouvelle donnée climatique
        Méthode HTTP : POST
        Endpoint : /api/donnees-climatiques
        Description : Permet d’ajouter une nouvelle donnée climatique dans la base de données.
        Corps requis : Un objet JSON représentant la donnée climatique à ajouter.

    Récupérer une donnée climatique par son ID
        Méthode HTTP : GET
        Endpoint : /api/donnees-climatiques/{id}
        Description : Renvoie la donnée climatique correspondant à l’ID donné.

    Mettre à jour une donnée climatique par son ID
        Méthode HTTP : PUT
        Endpoint : /api/donnees-climatiques/{id}
        Description : Met à jour la donnée climatique spécifiée par son ID.
        Corps requis : Un objet JSON représentant la donnée climatique mise à jour.

    Supprimer une donnée climatique par son ID
        Méthode HTTP : DELETE
        Endpoint : /api/donnees-climatiques/{id}
        Description : Supprime la donnée climatique correspondant à l’ID donné.

    Récupérer les données climatiques par date
        Méthode HTTP : GET
        Endpoint : /api/donnees-climatiques/date/{date}
        Description : Renvoie toutes les données climatiques correspondant à une date spécifique.


### Pour la table des Localisations ("Localisation")
    Récupérer toutes les localisations
        Méthode HTTP : GET
        Endpoint : /api/localisations
        Description : Renvoie la liste complète de toutes les localisations.

    Ajouter une nouvelle localisation
        Méthode HTTP : POST
        Endpoint : /api/localisations
        Description : Permet d’ajouter une nouvelle localisation dans la base de données.
        Corps requis : Un objet JSON représentant la localisation à ajouter.

    Récupérer une localisation par son ID
        Méthode HTTP : GET
        Endpoint : /api/localisations/{id}
        Description : Renvoie la localisation correspondant à l’ID donné.

    Mettre à jour une localisation par son ID
        Méthode HTTP : PUT
        Endpoint : /api/localisations/{id}
        Description : Met à jour la localisation spécifiée par son ID.
        Corps requis : Un objet JSON représentant la localisation mise à jour.

    Supprimer une localisation par son ID
        Méthode HTTP : DELETE
        Endpoint : /api/localisations/{id}
        Description : Supprime la localisation correspondant à l’ID donné.


## Rappel des schémas des BD utilisés (en attendant la vrai implementation sur la VM)
BDD -> Postgres

Table : "donnees_climatiques_jeux"


| **Champ**         | **Type**           |  
|-------------------|--------------------|  
| `id`              | `bigint`           |  
| `date`            | `character varying` |  
| `dd`              | `integer`          |  
| `hbas`            | `integer`          |  
| `u`               | `integer`          |  
| `nbas`            | `integer`          |  
| `n`               | `real`             |  
| `numer_sta`       | `integer`          |  
| `per`             | `real`             |  
| `td`              | `real`             |  
| `rr12`            | `real`             |  
| `pmer`            | `integer`          |  
| `pres`            | `integer`          |  
| `raf10`           | `real`             |  
| `rafper`          | `real`             |  
| `tx12`            | `real`             |  
| `tn12`            | `real`             |  
| `tminsol`         | `real`             |  
| `t`               | `real`             |  
| `ww`              | `integer`          |  
| `cod_tend`        | `integer`          |  
| `tend`            | `integer`          |  
| `tend24`          | `integer`          |  
| `vv`              | `real`             |  
| `ff`              | `real`             |  


Table : "localisation"

| **Champ**         | **Type**           |  
|-------------------|--------------------|  
| `id`              | `bigint`           |  
| `numer_sta`       | `integer`          |  
| `ville`           | `string`           |  
| `latitude`        | `float`            |  
| `longitude`       | `float`            |  
| `altitude`        | `integer`          |  


## En Cours...

:exclamation: :exclamation: :exclamation: 
- La récupération des données climatiques/localisation par autre chose que l'id (exemple : numéro de station...) est en cours de développement.
- Les tables issues de l'API AROME sont aussi en cours...  
