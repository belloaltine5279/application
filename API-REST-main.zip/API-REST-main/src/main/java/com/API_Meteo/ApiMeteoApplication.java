package com.API_Meteo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMeteoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMeteoApplication.class, args);
	}

}
