package com.API_Meteo.repository;

import com.API_Meteo.entites.DonneesClimatiques;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonneesClimatiquesRepository extends JpaRepository<DonneesClimatiques, Long> {
    List<DonneesClimatiques> findByDateBetween(String dateDebut, String dateFin);
    List<DonneesClimatiques> findByDateAfter(String dateDebut);
    List<DonneesClimatiques> findByDateBefore(String dateFin);
}