package com.API_Meteo.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.API_Meteo.entites.Localisation;

public interface LocalisationsRepository  extends JpaRepository<Localisation, Long> {

}
