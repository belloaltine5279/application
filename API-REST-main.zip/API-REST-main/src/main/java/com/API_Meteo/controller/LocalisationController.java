package com.API_Meteo.controller;

import com.API_Meteo.entites.Localisation;
import com.API_Meteo.repository.LocalisationsRepository;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/localisations")
public class LocalisationController {
    
    final LocalisationsRepository Repository;

    public LocalisationController(LocalisationsRepository repo) {
        this.Repository = repo;
    }

    // Recuperer TOUTES les localisations
    @GetMapping
    public ResponseEntity<List<Localisation>> getAllLocalisations() {
        return new ResponseEntity<>(this.Repository.findAll(),HttpStatus.OK);
    }

    // Ajouter des localisations
    @PostMapping
    public ResponseEntity<Localisation> addLocalisation(@RequestBody Localisation loc) {
        Localisation nouvelleLocalisation = this.Repository.save(loc);
        return new ResponseEntity<>(nouvelleLocalisation,HttpStatus.CREATED);
    }
    
    // Recuperer des données par l'id
    @GetMapping("/{id}")
    public ResponseEntity<Localisation> getLocalisationsById(@PathVariable Long id) {
       Optional<Localisation> loc =  this.Repository.findById(id);
       if(loc.isPresent()){
           return new ResponseEntity<>(loc.get(),HttpStatus.OK);
       }
       return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Modifier par l'id
    @PutMapping("/{id}")
    public ResponseEntity<Localisation> updateLocalisation(@PathVariable Long id, @RequestBody Localisation new_loc) {
        Optional<Localisation> loc = this.Repository.findById(id);
        if (loc.isPresent()) {
            new_loc.setId(loc.get().getId());
            Localisation loc_modifie = this.Repository.save(new_loc); 
            return new ResponseEntity<>(loc_modifie, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Supprimer par l'id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLocalisationById(@PathVariable Long id) {
        Optional<Localisation> loc =  this.Repository.findById(id);
        if(loc.isPresent()){
            this.Repository.delete(loc.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


}
