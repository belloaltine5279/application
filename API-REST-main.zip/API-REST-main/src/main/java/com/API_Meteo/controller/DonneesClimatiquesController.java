package com.API_Meteo.controller;

import com.API_Meteo.entites.DonneesClimatiques;
import com.API_Meteo.repository.DonneesClimatiquesRepository;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/donnees-climatiques")
public class DonneesClimatiquesController {

    final DonneesClimatiquesRepository Repository;

    public DonneesClimatiquesController(DonneesClimatiquesRepository repo) {
        this.Repository = repo;
    }

    // Recuperer TOUTES les données
    @GetMapping
    public ResponseEntity<List<DonneesClimatiques>> getAllDonneesClimatiques() {
        return new ResponseEntity<>(this.Repository.findAll(),HttpStatus.OK);
    }

    // Ajouter des données
    @PostMapping
    public ResponseEntity<DonneesClimatiques> addDonneesClimatiques(@RequestBody DonneesClimatiques donneesClimatiques) {
        DonneesClimatiques nouvelledonnee = this.Repository.save(donneesClimatiques);
        return new ResponseEntity<>(nouvelledonnee,HttpStatus.CREATED);
     }

    // Recuperer des données par l'id
    @GetMapping("/{id}")
    public ResponseEntity<DonneesClimatiques> getDonneesClimatiquesById(@PathVariable Long id) {
       Optional<DonneesClimatiques> Donnees =  this.Repository.findById(id);
       if(Donnees.isPresent()){
           return new ResponseEntity<>(Donnees.get(),HttpStatus.OK);
       }
       return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Modifier par l'id
    @PutMapping("/{id}")
    public ResponseEntity<DonneesClimatiques> updateDonneesClimatiques(@PathVariable Long id, @RequestBody DonneesClimatiques new_DonneeClima) {
        Optional<DonneesClimatiques> donnees = this.Repository.findById(id);
        if (donnees.isPresent()) {
            new_DonneeClima.setId(donnees.get().getId());
            new_DonneeClima.setNumer_sta(donnees.get().getNumer_sta());
            DonneesClimatiques donneeModifiee = this.Repository.save(new_DonneeClima); 
            return new ResponseEntity<>(donneeModifiee, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Supprimer par l'id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDonneesClimatiquesById(@PathVariable Long id) {
        Optional<DonneesClimatiques> Donnees =  this.Repository.findById(id);
        if(Donnees.isPresent()){
            this.Repository.delete(Donnees.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    // Recherche par Date ou Plage de Dates
    @GetMapping("/recherche")
    public ResponseEntity<List<DonneesClimatiques>> getDonneesClimatiquesByDate(
            @RequestParam(required = false) String dateDebut,
            @RequestParam(required = false) String dateFin) {
        List<DonneesClimatiques> donnees;
        if (dateDebut != null && dateFin != null) {
            donnees = this.Repository.findByDateBetween(dateDebut, dateFin);
        } else if (dateDebut != null) {
            donnees = this.Repository.findByDateAfter(dateDebut);
        } else if (dateFin != null) {
            donnees = this.Repository.findByDateBefore(dateFin);
        } else {
            donnees = this.Repository.findAll();
        }

        if (donnees.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(donnees, HttpStatus.OK);
    }


}