package com.API_Meteo.entites;

import jakarta.persistence.*;

@Entity
@Table(name = "DonneesClimatiques_jeux")
public class DonneesClimatiques {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "numer_sta", nullable = false)
    private int numer_sta;

    @Column(name = "date", nullable = false)
    private String date;

    @Column(name = "pmer")
    private int pmer;

    @Column(name = "tend")
    private int tend;

    @Column(name = "cod_tend")
    private int cod_tend;

    @Column(name = "dd")
    private int dd;

    @Column(name = "ff")
    private float ff;

    @Column(name = "t")
    private float t;

    @Column(name = "td")
    private float td;

    @Column(name = "u")
    private int u;

    @Column(name = "vv")
    private float vv;

    @Column(name = "ww")
    private int ww;

    @Column(name = "n")
    private float n;

    @Column(name = "nbas")
    private int nbas;

    @Column(name = "hbas")
    private int hbas;

    @Column(name = "pres")
    private int pres;

    @Column(name = "tend24")
    private int tend24;

    @Column(name = "tn12")
    private float tn12;

    @Column(name = "tx12")
    private float tx12;

    @Column(name = "tminsol")
    private float tminsol;

    @Column(name = "raf10")
    private float raf10;

    @Column(name = "rafper")
    private float rafper;

    @Column(name = "per")
    private float per;

    @Column(name = "rr12")
    private float rr12;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getNumer_sta() {
        return numer_sta;
    }

    public void setNumer_sta(int numer_sta) {
        this.numer_sta = numer_sta;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getPmer() {
        return pmer;
    }

    public void setPmer(int pmer) {
        this.pmer = pmer;
    }

    public int getTend() {
        return tend;
    }

    public void setTend(int tend) {
        this.tend = tend;
    }

    public int getCod_tend() {
        return cod_tend;
    }

    public void setCod_tend(int cod_tend) {
        this.cod_tend = cod_tend;
    }

    public int getDd() {
        return dd;
    }

    public void setDd(int dd) {
        this.dd = dd;
    }

    public float getFf() {
        return ff;
    }

    public void setFf(float ff) {
        this.ff = ff;
    }

    public float getT() {
        return t;
    }

    public void setT(float t) {
        this.t = t;
    }

    public float getTd() {
        return td;
    }

    public void setTd(float td) {
        this.td = td;
    }

    public int getU() {
        return u;
    }

    public void setU(int u) {
        this.u = u;
    }

    public float getVv() {
        return vv;
    }

    public void setVv(float vv) {
        this.vv = vv;
    }

    public int getWw() {
        return ww;
    }

    public void setWw(int ww) {
        this.ww = ww;
    }

    public float getN() {
        return n;
    }

    public void setN(float n) {
        this.n = n;
    }

    public int getNbas() {
        return nbas;
    }

    public void setNbas(int nbas) {
        this.nbas = nbas;
    }

    public int getHbas() {
        return hbas;
    }

    public void setHbas(int hbas) {
        this.hbas = hbas;
    }

    public int getPres() {
        return pres;
    }

    public void setPres(int pres) {
        this.pres = pres;
    }

    public int getTend24() {
        return tend24;
    }

    public void setTend24(int tend24) {
        this.tend24 = tend24;
    }

    public float getTn12() {
        return tn12;
    }

    public void setTn12(float tn12) {
        this.tn12 = tn12;
    }

    public float getTx12() {
        return tx12;
    }

    public void setTx12(float tx12) {
        this.tx12 = tx12;
    }

    public float getTminsol() {
        return tminsol;
    }

    public void setTminsol(float tminsol) {
        this.tminsol = tminsol;
    }

    public float getRaf10() {
        return raf10;
    }

    public void setRaf10(float raf10) {
        this.raf10 = raf10;
    }

    public float getRafper() {
        return rafper;
    }

    public void setRafper(float rafper) {
        this.rafper = rafper;
    }

    public float getPer() {
        return per;
    }

    public void setPer(float per) {
        this.per = per;
    }

    public float getRr12() {
        return rr12;
    }

    public void setRr12(float rr12) {
        this.rr12 = rr12;
    }
}
