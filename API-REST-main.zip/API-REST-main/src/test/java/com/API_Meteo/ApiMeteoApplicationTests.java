package com.API_Meteo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMeteoApplicationTests {

	@Test
	void contextLoads() {
	}

}
