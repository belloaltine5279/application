import { Component } from '@angular/core';

@Component({
  selector: 'app-home', // Vérifie que c'est correct
  standalone: true,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {}

