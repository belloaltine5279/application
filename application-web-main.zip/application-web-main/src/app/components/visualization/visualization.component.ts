import { Component } from '@angular/core';

@Component({
  selector: 'app-visualization',
  imports: [],
  templateUrl: './visualization.component.html',
  styleUrl: './visualization.component.css'
})
export class VisualizationComponent {

}
