import { Component } from '@angular/core';

@Component({
  selector: 'app-data-consultation',
  imports: [],
  templateUrl: './data-consultation.component.html',
  styleUrl: './data-consultation.component.css'
})
export class DataConsultationComponent {

}
